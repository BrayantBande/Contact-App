const formContact = document.querySelector('#form-contact');
const nameInput = document.querySelector('#name-input');
const numberInput = document.querySelector('#number-input');
const emailInput = document.querySelector('#email-input');
const formBtn = document.querySelector('#form-btn')
const contactList = document.querySelector('#contact-list');
const user = JSON.parse(localStorage.getItem('user'));
const closeBtn = document.querySelector('#cerrar-btn');


if (!user) {
    window.location.href = '../home/index.html';
}

//Regex
const EMAIL_REGEX = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@[g][m][a][i][l]+[.][c][o][m]+/;
const NAME_REGEX = /^[A-Z][a-zA-Z ]+[A-Z][a-zA-Z]+$/;
const NUMBER_REGEX = /^[4]{1}[1-2]{1}[246]{1}-[0-9]{7}$/;

// Validaciones
let emailValidation = false;
let nameValidation = false;
let numberValidation = false;

// Funciones
const validation = (inputValidation, e) => {
    formBtn.disabled = emailValidation && nameValidation && numberValidation ? false : true;
    if (inputValidation) {
        e.target.classList.remove('wrong');
        e.target.classList.add('correct');
        e.target.parentElement.children[1].classList.remove('show');
    } else {
        e.target.classList.remove('correct');
        e.target.classList.add('wrong');
        e.target.parentElement.children[1].classList.add('show');
    }
}

// Eventos

nameInput.addEventListener('input', e => {
    nameValidation = NAME_REGEX.test(e.target.value);
    validation(nameValidation, e);
});

numberInput.addEventListener(`input`, e => {
    numberValidation = NUMBER_REGEX.test(e.target.value)
    validation(numberValidation, e);
});

emailInput.addEventListener('input', e => {
    emailValidation = EMAIL_REGEX.test(e.target.value);
    validation(emailValidation, e);
});


formContact.addEventListener('submit', async e => {
    e.preventDefault();
    const responseJSON = await fetch('http://localhost:3000/contacts', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name: nameInput.value, number: numberInput.value, email: emailInput.value, user: user.username })
    });

    const response = await responseJSON.json();
    const listItem = document.createElement('li');
    listItem.innerHTML = `
    <li class="todo-item" id='${response.id}'>
    <button class="delete-btn">ELIMINAR</button> 
    <p class="contact"> ${response.name}</p>
    <p class="contact"> ${response.number}</p>
    <p class="contact"id> ${response.email}</p>
    <button class="edit-btn">EDITAR</button>
      </li>
`
    contactList.append(listItem);
    nameInput.value = '';
    numberInput.value = '';
    emailInput.value = '';
    emailInput.classList.remove(`correct`);
    nameInput.classList.remove(`correct`);
    numberInput.classList.remove(`correct`);
    formBtn.disabled = true;
});


contactList.addEventListener('click', async e => {
    if (e.target.classList.contains('delete-btn')) {
        const id = e.target.parentElement.id;
        await fetch(`http://localhost:3000/contacts/${id}`, { method: 'DELETE' });
        e.target.parentElement.remove()
        console.log(id);
    } if (e.target.classList.contains('edit-btn')) {
        const name = e.target.parentElement.children[1].textContent;
        const number = e.target.parentElement.children[2].textContent;
        const email = e.target.parentElement.children[3].textContent;
        const button = e.target;
        console.log(email);
        console.log(name);
        console.log(number);
        const li = button.parentNode;
        console.log(li);
        (`http://localhost:3000/contacts/${name}${number}${email}`, { method: 'PATCH' });

    }

});

closeBtn.addEventListener('click', async e => {
    localStorage.removeItem('user');
    window.location.href = '../home/index.html'
});





const getContacts = async () => {
    const response = await fetch('http://localhost:3000/contacts', { method: 'GET' });
    const contacts = await response.json();
    console.log(contacts);
    const userContacts = contacts.filter(contacts => contacts.user === user.username);
    console.log(userContacts);
    userContacts.forEach(contacts => {
        const listItem = document.createElement('li');
        listItem.innerHTML =
            `
    <li class="todo-item" id='${contacts.id}'>
    <button class="delete-btn">ELIMINAR</button> 
    <p class="contact"> ${contacts.name}</p>
    <p class="contact"> ${contacts.number}</p>
    <p class="contact"> ${contacts.email}</p>
    <button class="edit-btn">EDITAR</button>
      </li>
      `
        contactList.append(listItem);
    });
}

getContacts();